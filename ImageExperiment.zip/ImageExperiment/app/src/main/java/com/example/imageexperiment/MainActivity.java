package com.example.imageexperiment;

import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private RelativeLayout layout;
    private boolean isBackgroundOne = true;
    private final int[] backgroundImages = {R.drawable.shiba, R.drawable.shiba2}; // Array for backgrounds
    private int currentBackgroundIndex = 0; // Track current background

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout);
        Button switchBackgroundButton = findViewById(R.id.switchBackgroundButton);

        // Define the fade-in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(500); // Duration of animation in milliseconds

        // Set up single click listener with fade animation and background switching logic
        switchBackgroundButton.setOnClickListener(v -> {
            currentBackgroundIndex = (currentBackgroundIndex + 1) % backgroundImages.length;
            layout.startAnimation(fadeIn); // Start the fade animation
            layout.setBackgroundResource(backgroundImages[currentBackgroundIndex]); // Switch background
        });
    }
}


